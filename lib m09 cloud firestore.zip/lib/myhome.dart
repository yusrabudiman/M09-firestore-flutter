import 'dart:convert';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:my_firebase_test1/eventmodel.dart';

class MyHome extends StatefulWidget {
  const MyHome({super.key});

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  List<EventModel> details = [];

  Future readData() async {
    await Firebase.initializeApp();
    FirebaseFirestore db = await FirebaseFirestore.instance;
    var data = await db.collection('event_detail').get();
    setState(() {
      details =
          data.docs.map((doc) => EventModel.fromDocSnapshot(doc)).toList();
    });
  }

  addRand() async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    EventModel InsertData = EventModel(
        judul: getRandString(5),
        keterangan: getRandString(30),
        tanggal: getRandString(10),
        is_like: Random().nextBool(),
        pembicara: getRandString(20));
    DocumentReference docRef =
        await db.collection("event_detail").add(InsertData.toMap());
    InsertData.id = docRef.id;
    setState(() {
      details.add(InsertData);
    });
  }

  deleteLast(String documentId) async {
    FirebaseFirestore db = await FirebaseFirestore.instance;
    await db.collection("event_detail").doc(documentId).delete();
    setState(() {
      details.removeLast();
    });
  }

  updateEvent(int position, String newJudul, String newKeterangan,
      String newPembicara, String newTanggal, bool newIsLike) async {
    if (details.isNotEmpty && position < details.length) {
      FirebaseFirestore db = await FirebaseFirestore.instance;
      await db.collection("event_detail").doc(details[position].id).update({
        'Judul': newJudul,
        'Keterangan': newKeterangan,
        'Pembicara': newPembicara,
        'tanggal': newTanggal,
        'is_like': newIsLike
      });
      setState(() {
        details[position].judul = newJudul;
        details[position].keterangan = newKeterangan;
        details[position].pembicara = newPembicara;
        details[position].tanggal = newTanggal;
        details[position].is_like = newIsLike;
      });
    } else {
      print('Invalid position: $position for details list.');
    }
  }

  String getRandString(int len) {
    var random = Random.secure();
    var values = List<int>.generate(len, (i) => random.nextInt(255));
    return base64Encode(values);
  }

  @override
  void initState() {
    readData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cloud firestore'),
      ),
      body: ListView.builder(
        itemCount: details.length,
        itemBuilder: (context, position) {
          return ListTile(
            title: Text(details[position].judul),
            subtitle: Text(
                "${details[position].keterangan}\nHari : ${details[position].tanggal}\nPembicara : ${details[position].pembicara}"),
            isThreeLine: true,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                IconButton(
                  color: Color.fromARGB(255, 60, 167, 199),
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        String? newJudul = details[position].judul;
                        String? newKeterangan = details[position].keterangan;
                        String? newPembicara = details[position].pembicara;
                        String? newTanggal = details[position].tanggal;
                        bool? newIsLike = details[position].is_like;
                        return StatefulBuilder(
                          builder: (context, setState) {
                            return AlertDialog(
                              title: Text('Edit Item'),
                              content: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    TextField(
                                      onChanged: (value) {
                                        setState(() {
                                          newJudul = value;
                                        });
                                      },
                                      controller:
                                          TextEditingController(text: newJudul)
                                            ..selection =
                                                TextSelection.collapsed(
                                                    offset: newJudul!.length),
                                      decoration:
                                          InputDecoration(labelText: 'Judul'),
                                    ),
                                    TextField(
                                      onChanged: (value) {
                                        setState(() {
                                          newKeterangan = value;
                                        });
                                      },
                                      controller: TextEditingController(
                                          text: newKeterangan)
                                        ..selection = TextSelection.collapsed(
                                            offset: newKeterangan!.length),
                                      decoration: InputDecoration(
                                          labelText: 'Keterangan'),
                                    ),
                                    TextField(
                                      onChanged: (value) {
                                        setState(() {
                                          newPembicara = value;
                                        });
                                      },
                                      controller: TextEditingController(
                                          text: newPembicara)
                                        ..selection = TextSelection.collapsed(
                                            offset: newPembicara!.length),
                                      decoration: InputDecoration(
                                          labelText: 'Pembicara'),
                                    ),
                                    TextField(
                                      onChanged: (value) {
                                        setState(() {
                                          newTanggal = value;
                                        });
                                      },
                                      controller: TextEditingController(
                                          text: newTanggal)
                                        ..selection = TextSelection.collapsed(
                                            offset: newTanggal!.length),
                                      decoration:
                                          InputDecoration(labelText: 'Tanggal'),
                                    ),
                                    CheckboxListTile(
                                      title: Text('Is like bool'),
                                      value: newIsLike,
                                      onChanged: (bool? value) {
                                        setState(() {
                                          newIsLike = value;
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                              actions: <Widget>[
                                TextButton(
                                  child: Text('Cancel'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                                TextButton(
                                  child: Text('Save'),
                                  onPressed: () async {
                                    if (newJudul != null &&
                                        newJudul!.isNotEmpty &&
                                        newKeterangan != null &&
                                        newKeterangan!.isNotEmpty &&
                                        newPembicara != null &&
                                        newPembicara!.isNotEmpty &&
                                        newTanggal != null &&
                                        newTanggal!.isNotEmpty) {
                                      // Update the fields in Firebase
                                      updateEvent(
                                          position,
                                          newJudul!,
                                          newKeterangan!,
                                          newPembicara!,
                                          newTanggal!,
                                          newIsLike!);
                                      Navigator.of(context).pop();
                                    } else {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title: Text('Error'),
                                            content: Text(
                                                'Perubahan tidak dapat disimpan, karena salah satu atau beberapa kolom tidak terisi'),
                                            actions: <Widget>[
                                              TextButton(
                                                child: Text('OK'),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    }
                                  },
                                ),
                              ],
                            );
                          },
                        );
                      },
                    );
                  },
                ),
                IconButton(
                  color: Color.fromARGB(255, 232, 89, 89),
                  icon: Icon(Icons.delete),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: Text('Delete Item'),
                          content: Text(
                              'Apa kamu yakin ingin hapus daftar item ini ?'),
                          actions: <Widget>[
                            TextButton(
                              child: Text('No'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            TextButton(
                              child: Text('Yes'),
                              onPressed: () {
                                deleteLast(details[position].id!);
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FabCircularMenu(children: <Widget>[
        IconButton(
            onPressed: () {
              addRand();
            },
            icon: Icon(Icons.add)),
        IconButton(
            onPressed: () {
              if (details.isNotEmpty && details.last.id != null) {
                deleteLast(details.last.id!);
              } else {
                print('List is no available');
              }
            },
            icon: Icon(Icons.minimize))
      ]),
    );
  }
}
